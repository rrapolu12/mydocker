#!/bin/bash
set -euo pipefail
#sudo docker build -t cityapp:2.0 .
docker build -t cityapp:1.0 .
